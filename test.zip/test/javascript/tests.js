
QUnit.test('one should equal one', function(assert) {
	assert.equal(1, 1, 'error: one did not equal one');
});

QUnit.test('one should not equal four', function(assert) {
	assert.equal(1, 4, 'error: one did not equal four');
});

test('basic test', function() {
  expect(1);
  ok(true, 'this had better work.');
});

QUnit.test('one should not equal four', function(assert) {
	assert.equal(1, 45, 'error: failed!!!!');
});

