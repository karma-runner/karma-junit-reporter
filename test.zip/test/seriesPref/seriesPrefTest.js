
describe('SeriesPrefTest', function() {
  var $scope, ctrl, $timeout_;
  var seriesPrefService;
  beforeEach(function (){
	seriesPrefService = jasmine.createSpyObj('seriesPreferenceService',['displaySeriesPreference','getSeriesData','saveSeriesPreference']);
    module('TPV-ui-module');
    inject(function($controller,$q,$timeout) {
    $scope 		= $baseTestScope;
	$timeout_	= $timeout;
	//deferred = $q.defer();
	//$q.when(loadRegionsData)
	//seriesPrefService.displaySeriesPreference.and.returnValue(deferred.promise);
	
	seriesPrefService.getSeriesData.and.returnValue(loadSerPrefData);
	
	seriesPrefService.displaySeriesPreference.and.callFake(function(data){
		return {
	          then: function(response){
	            response(loadSerPrefData);
	          }
	        }
	});
	seriesPrefService.saveSeriesPreference.and.callFake(function(data){
		return {
	          then: function(response){
	            response(loadSerPrefData);
	          }
	        }
	});
    
   ctrl = $controller('seriesPreferenceController', {
    '$scope':$scope,
	'$timeout':$timeout,
    'seriesPreferenceService':seriesPrefService
    });
	$baseTestScope.$apply();
    });
  });
   
  /* Test 2: default values should be applied*/
  it('findSeries Preference', function (){
	$baseRootScope.$broadcast("openSeriesPreference");
	$scope.$apply();
	expect($scope.seriesPref.responseData.agedStockTotal).toEqual('50');
	expect($scope.seriesPref.responseData.colorDescIn).toBeTruthy();
	expect($scope.seriesPref.responseData.getSudo).toEqual('DEC 2014');
	expect($scope.seriesPref.responseData.gradeRollupIn).toBeTruthy();
	expect($scope.seriesPref.responseData.mycInd).toBeFalsy();
	expect($scope.seriesPref.responseData.tpvSalesWeightTOs.length).toEqual(1);
	expect($scope.seriesPref.exception).toBeNull();
	expect($scope.bodycssClass).toEqual('module-ppr');
  });
  
  it('save series pref', function (){
	  $baseRootScope.$broadcast("saveSeriesPreference");
	  expect($scope.errorMessage.length).toEqual(0);
	  expect($scope.errorMessage).toEqual([]);
  });
});