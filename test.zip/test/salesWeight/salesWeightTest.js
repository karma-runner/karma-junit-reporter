jQuery.fn.modal=function(){};

describe('salesWeightTest', function() {
  var $scope, ctrl, $timeout_;
  var salesWeightServiceTest;
  
  it('find sales weight information', function () {
	  //create mock and controller instance
	  	module('TPV-ui-module');
	    inject(function($controller,$q,$timeout,$filter,salesWeightService) {
	    $scope 		= $baseTestScope;
		$timeout_	= $timeout;
		salesWeightServiceTest = salesWeightService;
		var getSalesWeightDataFn = function(selectionTos,callbackfun) {
			setSalesWghtData(loadSalesWeightData);
		}	
		var setSalesWghtData = function(responseData) {
			baseModuleServiceTest.salesWeightData	= responseData;
			$scope.salesWeightData					= baseModuleServiceTest.salesWeightData;
		}
		salesWeightService.getSalesWeightData = getSalesWeightDataFn;
		salesWeightService.saveSalesWeight = function($scope){
		}
	   ctrl = $controller('salesWeightController', {
	    '$scope':$scope,
	    '$filter':$filter,
		'$timeout':$timeout,
	    'salesWeightService':salesWeightService,
	    'baseModuleService':baseModuleServiceTest
	    });
		$baseTestScope.$apply();
	    });
	    
	$baseRootScope.$broadcast("openSalesWgtDODSettings");
	$scope.$apply();
	expect($scope.salesWeightData.responseData[0].distributorId).toEqual(145);
	expect($scope.salesWeightData.responseData[0].seriesName).toEqual("HIGHLANDER HYBRID");
	expect($scope.salesWeightData.responseData[0].regionId).toEqual(16);
	expect($scope.salesWeightData.responseData[0].totalErrorInd).toBeFalsy();
	expect($scope.salesWeightData.responseData[0].tpvSalesWeightPctTOs.length).toEqual(7);
	expect($scope.salesWeightData.responseData[0].tpvSalesWeightPctTOs[0].percentage).toEqual("15.0");
	expect($scope.salesWeightData.responseData[0].tpvSalesWeightPctTOs[0].month).toEqual(0);
  });
  it('save sales weight', function () {
	  $baseRootScope.$broadcast("saveSalesWeight");
	  expect($scope.percentageWarnMsg).toEqual('Some of the series does not have their Total equal to 100%. Do you want to continue?');
  });
});