var $baseTestScope;
var $baseRootScope;
var baseServiceMockObj;
var baseModuleServiceTest;
describe('HomeTest', function() {
  var $scope, ctrl, $timeout_;

  // This function will be called before every "it" block.
  // This should be used to "reset" state for your tests.
  beforeEach(function (){
    // Create a "spy object" for our someService.
    // This will isolate the controller we're testing from
    // any other code.
    // we'll set up the returns for this later 
	baseServiceMockObj = jasmine.createSpyObj('baseModuleService',['loadGetSudoMonth','loadDistributors',
	                                                               'loadRegions','loadDivisions','custViewDetails']);
    // load the module you're testing.
    module('TPV-ui-module');
    // INJECT! This part is critical
    // $rootScope - injected to create a new $scope instance.
    // $controller - injected to create an instance of our controller.
    // $q - injected so we can create promises for our mocks.
    // _$timeout_ - injected to we can flush unresolved promises.
    inject(function($rootScope,$controller,$q,$timeout,baseModuleService,$location) {
    // create a scope object for us to use.
    $baseRootScope=$rootScope;
    $scope = $rootScope.$new();
    $baseTestScope=$scope;
	$timeout_=$timeout;
	baseModuleServiceTest=baseModuleService;
    // set up the returns for our baseServiceMockObj
    // $q.when('weee') creates a resolved promise to "weee".
    // this is important since our service is async and returns
    // a promise.
	baseServiceMockObj.loadRegions.and.returnValue($q.when(loadRegionsData));
	baseServiceMockObj.loadDivisions.and.returnValue($q.when(loadDivisionsData));
	baseServiceMockObj.loadGetSudoMonth.and.returnValue($q.when(loadGetSudoMonthData));
	baseServiceMockObj.loadDistributors.and.returnValue($q.when(loadDistributorsData));
	baseServiceMockObj.custViewDetails.and.returnValue([loadColumnLkpDetail.responseData,loadCustomViewsData.responseData,fetchCheckedColumns.responseData]);
	spyOn($baseRootScope, '$broadcast').and.callThrough();;

    // assign $timeout to a scoped variable so we can use 
    // $timeout.flush() later. Notice the _underscore_ trick
    // so we can keep our names clean in the tests.
    //$	 = _$timeout_;
    // now run that scope through the controller function,
    // injecting any services or other injectables we need.
    // **NOTE**: this is the only time the controller function
    // will be run, so anything that occurs inside of that
    // will already be done before the first spec.
    ctrl = $controller('baseController', {
    '$scope':$scope,
	'$timeout':$timeout,
    'baseModuleService':baseServiceMockObj,
    '$location':$location
    });
	$rootScope.$apply();
    });
  });
   
  /* Test 2: default values should be applied*/
  it('searchbar default data to be applied', function (){
	expect($scope.bodycssClass).toEqual('module-ppr');
	expect($scope.sfDistributor.dropdownKey).not.toBeNull();
	expect($scope.sfDivision.dropdownKey).not.toBeNull();
	expect($scope.sfRegion.dropdownKey).not.toBeNull();
	expect($scope.sfGetSudoMonth).not.toBeNull();
	expect($scope.sfSalesType.dropdownKey).not.toBeNull();
	expect($scope.sfDistributor.dropdownValue).not.toBeNull();
	expect($scope.sfDivision.dropdownValue).not.toBeNull();
	expect($scope.sfRegion.dropdownValue).not.toBeNull();
  });
  
  it('should update baz when bar is changed', function (){
    $scope.bodycssClass = 'test';
    $scope.$apply();
    expect($scope.bodycssClass).toEqual('test');
  });

  it('should update fizz asynchronously when test2() is called', function (){
    expect(baseServiceMockObj.loadGetSudoMonth).toHaveBeenCalled();  
    $timeout_.flush();
  });
});