
describe('calculatePPRMix', function() {
  var $scope, ctrl, $timeout_;
  
  it('CalculatePPRMixUI Loading', function (){
	  
    	module('TPV-ui-module');
	    inject(function($controller,$q,$timeout,$http) {
	    $scope 		= $baseTestScope;
		$timeout_	= $timeout;
	   ctrl = $controller('portModelController', {
	    '$scope':$scope,
	    '$http':$http,
		'$timeout':$timeout,
		'$q':$q
	    });
		$baseTestScope.$apply();
	    });
	    
	$scope.portModelData = calcPPRMixPortModelData.responseData;
	$scope.portModelHeader = $scope.getCustViewDetails()[0];
	$scope.viewableHeaders = $scope.getCustViewDetails()[2];
	$scope.validateViewableColumn();
	expect($scope.bodycssClass).toEqual('module-ppr');
	$scope.$apply();
  });
  it('CalculatePPRMixUI Load Model Tab', function (){
	  $scope.loadModel(2,'PORTLAND');
	  expect($scope.lastSelectedTab).toEqual("ModelsTab");
	  expect($scope.lastSelectedPortName).toEqual("Port: PORTLAND");
	  expect($scope.bodycssClass).toEqual('module-ppr');
 });
  it('CalculatePPRMixUI Load Option/Color Tab', function (){
	$scope.selectedModel=2014;
	$scope.setLastSelectedTab("OptionsTab");
	expect($scope.lastSelectedPortName).toEqual("Port: PORTLAND");
	expect($scope.lastSelectedModelName).toEqual("Model: 2014");
  });
  it('CalculatePPRMixUI Navigate to port Tab', function (){
		$scope.setLastSelectedTab("PortsTab");
		expect($scope.lastSelectedPortName).toEqual("Ports");
		expect($scope.lastSelectedModelName).toEqual("Models");
  });
  
});